package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabBookRegister2Application {

	public static void main(String[] args) {
		SpringApplication.run(CabBookRegister2Application.class, args);
	}

}
